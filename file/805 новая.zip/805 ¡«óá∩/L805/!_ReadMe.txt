You can make all adjustments with Epson L805 printer by Adjustment Program.

www.2manuals.com 