Check the EEPROM & Product serial.


� Then type the Product serial in the box, ex: TP3K95891.
   Re-input. then click perform "PERFORM"

click the pop-up messages, "YES" and "OK"


"Attention!! if you have ERROR that's normal

POWER OFF THE PRINTER
THEN
POWER ON THE PRINTER